 package simulation;

import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import static simulation.NextTask.nexttask;
import static simulation.ProfileIntegrationProcess.LastTask;
import static simulation.QueueAddInput.queueaddinput;
import static simulation.Start.duration;
import static simulation.Start.makespan;
import static simulation.Start.maxduration;
import static simulation.Start.messproc;
import static simulation.Start.preemptask;
import static simulation.Start.queues;
import static simulation.Start.start;

/**
 *
 * @author DANI
 * Executa tarefa da fila e gera a prox tarefa
 */
public class AllocateThread {
    
    public static int ptask; 
    
    public static void allocatethread(Queue<Integer> q, int preemp){
    
        ExecutorService executor = Executors.newCachedThreadPool(new MyThreadFactory());
        
        int task ; 
        int lasttask = 0;
        int count = 10;
                
        for(int i = 1; i <= preemp; i++){
//            System.out.println(queues[0].size());
            if (duration<maxduration){  
             if (i==count){
                 queueaddinput();
                 count=count+1000;
//                 System.out.println(queues[0].size());
             }  
                if (q.peek() != null){
                    task = q.peek();
                    ptask = task;//enviada para Operation

                    Runnable runnable1 = () -> {
                        executor.submit(new Operation());
                        };     

                    for(int j = 0; j < LastTask.length; j++){//ate a ultima tarefa do processo de integracao

                        if (task == LastTask[j]){
                           lasttask = 1;
                        }
                    }
                        if (lasttask == 0 && task !=0){  //se nao for a ultima tarefa, gera indicação da prox tarefa
    //                        System.out.println(task);
                            nexttask(task);
                            } 
                        else{
                            messproc = messproc + 1;  //mensagens processaadas
                            makespan = System.nanoTime() - start;
//                           System.out.println("procs:" + messproc + " "+ "resta:"+queues[0].size());
                            }  


                    task = q.remove();     

                    executor.shutdownNow();
                }  
                if (preemptask == 0 || q.size() < preemp){
                    preemp = q.size();
                    }
                else{
                    preemp = preemptask;
                    }
                } 
             else{
                    i = preemp+ 1; ;
                }
            duration = System.nanoTime() - start; 
        }
        count = 10;
    }    
}