package simulation;

import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import static simulation.NextTask.nexttask;
import static simulation.ProfileIntegrationProcess.LastTask;
import static simulation.QueueAddInput.queueaddinput;
import static simulation.Start.duration;
import static simulation.Start.maxduration;
import static simulation.Start.starttime;
import static simulation.Start.endtime;
import static simulation.Start.messproc;
import static simulation.Start.preemptask;
import static simulation.Start.start;
import static simulation.Start.maxmessages;

/**
 *
 * @author DANI Executa tarefa da fila e gera a prox tarefa
 */
public class AllocateThread {

    public static int ptask;

    public static void allocatethread(Queue<Integer> q, int preemp) {

        ExecutorService executor = Executors.newCachedThreadPool(new MyThreadFactory());

        int task;
        int lasttask = 0;
        double count = 100;
        double end;

        for (int i = 1; i <= preemp; i++) {
//            System.out.println(queues[0].size());
            if (duration < maxduration) {

                if (q.peek() != null) {
                    task = q.peek();
                    ptask = task;//enviada para Operation

                    Runnable runnable1 = () -> {
                        executor.submit(new Operation());
                    };

                    for (int j = 0; j < LastTask.length; j++) {//ate a ultima tarefa do processo de integracao

                        if (task == LastTask[j]) {
                            lasttask = 1;
                        }
                    }
                    if (lasttask == 0 && task != 0) {  //se nao for a ultima tarefa, gera indicação da prox tarefa
                        nexttask(task);
                    } else {
                        //Adiciona o tempo de saida de cada messagen
                        end = System.nanoTime();
                        endtime.add(end);
                        messproc = messproc + 1;  //mensagens processaadas
                    }

                    q.remove();

                    executor.shutdownNow();
                }
                if (preemptask == 0 || q.size() < preemp) {
                    preemp = q.size();
                } else {
                    preemp = preemptask;
                }
            } else {
                i = preemp + 1;
            }
            duration = System.nanoTime() - start;

            if (maxmessages > starttime.size()) {
                if (i == count) {
                    queueaddinput();
                    count = count + 100;
                    //                 System.out.println(queues[0].size());
                }
            } else {
                duration = maxduration;
            }
        }
    }
}
