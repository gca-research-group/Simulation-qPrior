package simulation;

import java.util.Random;
import static simulation.ProfileIntegrationProcess.VetorNextTask;
import static simulation.ProfileIntegrationProcess.VetorOper;
import static simulation.QueueAdd.queueadd;

/**
 *
 * @author DANI
 * gera tarefa para a fila de prox nivel de tarefa(maior que nivel atual)
 * o nivel corresponde a quantidade de tarefas no maior caminho de tarefas predecessoras
 */
public class NextTask {
    public static void nexttask(int task) {  
        
        Random r = new Random();
        int nexttask; //proxima tarefa a ser executada
        
        //gera indicação da prox tarefa aleatoriamente

            int rad;
            rad = 1;
            String oper_rad;
            int operleng;
            int t;
//            int test;
            
            t = task -1;

            operleng = VetorOper[t].length;

            switch (operleng){
                case 0 : // tarefa simples
                {
                    nexttask = VetorNextTask[t][0];
                    queueadd(nexttask);
                    break;
                }
                case 1: case 2 : // tarefa fork que pode ser {{"and"},{"or"},{"and","or"}}
                {
                    if (operleng == 2){// tarefa fork ={"and","or"}
                        rad = r.nextInt(1);
                        oper_rad = VetorOper[t][rad];// sorteia um dos valores: "and" ou "or"
                    }
                    else {
                        oper_rad = VetorOper[t][0];// pode apenas um dos valores: "and" ou "or"
                    }
                    if ("or".equals(oper_rad)) {// tarefa fork ={"or"}
                        rad = r.nextInt(VetorNextTask[t].length);

                        nexttask = VetorNextTask[t][rad];
                        
                        queueadd(nexttask);
                    } 
                    else {
                        if ("and".equals(oper_rad)) {// tarefa fork ={"and"}
                            for (int i = 1; i < VetorNextTask[t].length; i++){
                                nexttask = VetorNextTask[t][i];
                                queueadd(nexttask);
                            }    
                        } 
                    }
                    break; 
                }    
            }
        }
    }
