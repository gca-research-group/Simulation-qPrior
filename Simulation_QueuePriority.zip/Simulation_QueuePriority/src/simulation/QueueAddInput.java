package simulation;

import static simulation.Start.maxmessages;
import static simulation.Start.numinputtask;
import static simulation.Start.policy;
import static simulation.Start.queues;
import static simulation.Start.starttime;

/**
 *
 * @author DANI simula a entrada de novas tarefas
 */
public class QueueAddInput {

    public static void queueaddinput() {

        double str;

        if (maxmessages - starttime.size() < numinputtask) {
            numinputtask = maxmessages - starttime.size();
        }

        for (int i = 0; i < numinputtask; i++) {
            str = System.nanoTime();
            starttime.add(str);

            //Adiciona "numinstance" tarefas 1 para queues[0] (queuefifo) 
            if ("FIFO".equals(policy)) {
                queues[0].add(1);
            } //Adiciona "numinstance" tarefas 1 para queues[1] (queueRR1)
            else {
                queues[1].add(1);
            }
        }

    }
}
