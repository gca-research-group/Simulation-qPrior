package simulation;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import static simulation.Fifo.fifo;
import static simulation.RoundRobin.roundrobin;
import static simulation.QueuePriority.queuepriority;
import static simulation.GravarArquivo.GravarArquivo;
import static simulation.ProfileIntegrationProcess.NumTasks;

/**
 *
 * @author DANI simula execucao de processo de integracao com politica fifo,
 * round robin e round robin com preempcao
 */
public class Start {

    public static int numsimulation = 25;
    public static int numtask = NumTasks;
    public static double numinstance = 1E3;
    public static double numinputtask = 1E3;
    public static double maxduration = 6E10;
    public static double maxmessages = 2E7;
    public static int preemptask = 100;
    public static double makespan = 0;
    public static Random gerador = new Random();
    public static double start;
    public static double end;
    public static double duration;
    public static double avgmakespan = 0;
    public static double throughput = 0;
    public static int messproc = 0;
    public static int messrem = 0;
    public static double deltatime = 0;

//    public static String policy = "FIFO";// usa Fifo 
//    public static String policy = "RR";//usa RR
//    public static String policy = "MqRR";//usa RR com preempcao
    public static String policy = "QueuePriority";//usa prioridade para as ultimas filas

    public static final Queue<Integer>[] queues = new Queue[numtask + 1];

    public static final ArrayList<Double> starttime = new ArrayList<Double>(1000000);//tempos de chegada de cada mensagem;
    public static final ArrayList<Double> endtime = new ArrayList<Double>(1000000);//tempos de saida de cada mensagem;

    static StringBuilder simulationText = new StringBuilder();

    public static void main(String args[]) throws InterruptedException {

        String simulationFile = "Simulation.txt";

        int cont = 0;
        double str = 0;

        //Executa 25 simulacoes       
        while (cont < numsimulation) {

            if ("FIFO".equals(policy)) {
                queues[0] = new LinkedList<>();
            } else {
                //Criando uma fila por tarefa
                for (int i = 1; i <= numtask; i++) {

                    queues[i] = new LinkedList<>();
                }
            }

            System.out.println("\n*Start Simulation " + policy + " " + (cont + 1) + " ...");
            start = System.nanoTime();

            //Adiciona "numinstance" tarefas 1 to queues[0] (queuefifo) e queues[1] (queueRR1)
            for (int i = 0; i < numinstance; i++) {
                //Adiciona o tempo de chegada de cada messagen
                str = System.nanoTime();
                starttime.add(str);

                //Adiciona um numero de "numinstance" tarefas 1 para queues[0] (queuefifo) 
                if ("FIFO".equals(policy)) {
                    queues[0].add(1);
                } //Adiciona um numero de "numinstance" tarefas 1 para queues[1] (queue[1])
                else {
                    queues[1].add(1);
                }
            }

            switch (policy) {
                case "FIFO": {
                    simulationFile = "SimulationFIFO.txt";
                    fifo();
                    break;
                }
                case "RR": {
                    simulationFile = "SimulationRR.txt";
                    roundrobin();
                    preemptask = 0;
                    break;
                }
                case "MqRR": {
                    simulationFile = "SimulationMqRR.txt";
                    roundrobin();
                    break;
                }
                case "QueuePriority": {
                    simulationFile = "SimulationqPrior.txt";
                    queuepriority();
                    break;
                }
            }

            cont++;

            System.out.println("\n*End Simulation " + policy + " " + (cont) + " ...");

            messproc = endtime.size();

            if (messproc > 0) {

                //calcula o makespan acumulado
                for (int i = 0; i < messproc; i++) {
                    makespan = makespan + (endtime.get(i) - starttime.get(i));   
                }

                deltatime = endtime.get(messproc - 1) - starttime.get(0);
                avgmakespan = ((makespan / 1000000000) / messproc);
                throughput = (messproc / (deltatime / 1000000000));
                messrem = starttime.size() - endtime.size();

                System.out.println("Total of messages = " + starttime.size());
                System.out.println("Total processed = " + messproc);
                System.out.println("Total remaining = " + messrem);
                System.out.println("makespan(s) = " + avgmakespan);
                System.out.println("throughput(messages/second) = " + throughput);

                simulationText.append(messproc).append(" ").append(messrem).append(" ").append(avgmakespan).append(" ").append(throughput).append("\n");
                GravarArquivo(simulationFile, simulationText.toString());
            }
            deltatime = 0;
            throughput = 0;
            avgmakespan = 0;
            makespan = 0;
            messproc = 0;
            messrem = 0;
            duration = 0;
            starttime.clear();
            endtime.clear();
        }
    }
}
