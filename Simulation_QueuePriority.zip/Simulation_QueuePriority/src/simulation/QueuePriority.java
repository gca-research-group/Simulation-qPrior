/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulation;

import static simulation.AllocateThread.allocatethread;
import static simulation.Start.duration;
import static simulation.Start.maxduration;
import static simulation.Start.numtask;
import static simulation.Start.preemptask;
import static simulation.Start.queues;
import static simulation.Start.start;

/**
 *
 * @author DANI
 */
public class QueuePriority {
    public static void queuepriority() throws InterruptedException {
        int totsize = 1;//tamanho total das filas
        int preemp = preemptask;
        int qprior = numtask;
                
        while (totsize>0 && duration<maxduration){   
            //System.out.println(queues[1].size());
            for(int i = numtask ; i >= 1; i--){
                if (!queues[i].isEmpty()) {
                    qprior = i;
                    i=1;
                }
            }    
                          
            if (preemp == 0 || queues[qprior].size() < preemp){
                preemp = queues[qprior].size();
                }
            else{
                preemp = preemptask;
                }
//            System.out.println("antes"+queues[qprior].size());
//                    System.out.println(preemp);
            allocatethread(queues[qprior],preemp);
//            System.out.println("depois allocate"+queues[qprior].size());

        }    
            
            totsize = 0;
            
            for(int j = 1; j <= numtask; j++){
                totsize =  totsize + queues[j].size();
            } 
            
            duration = System.nanoTime() - start;    
        }    
}
